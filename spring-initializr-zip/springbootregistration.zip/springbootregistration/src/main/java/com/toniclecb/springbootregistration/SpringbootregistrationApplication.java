package com.toniclecb.springbootregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootregistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootregistrationApplication.class, args);
	}

}
